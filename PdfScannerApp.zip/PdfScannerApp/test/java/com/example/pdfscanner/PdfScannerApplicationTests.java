package com.example.pdfscanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfScannerApplicationTests {
    @Test
    void contextLoads() {
    }
}
