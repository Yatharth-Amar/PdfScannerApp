package com.example.pdfscanner.model;

public class PDFRecord {
    private String sha256;
    private String pdfVersion;
    private String producer;
    private String author;
    private String createdDate;
    private String updatedDate;
    private String submissionDate;
    private String status; // processing, done, error
    private String error;

    public String getSha256() { return sha256; }
    public void setSha256(String sha256) { this.sha256 = sha256; }

    public String getPdfVersion() { return pdfVersion; }
    public void setPdfVersion(String pdfVersion) { this.pdfVersion = pdfVersion; }

    public String getProducer() { return producer; }
    public void setProducer(String producer) { this.producer = producer; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getCreatedDate() { return createdDate; }
    public void setCreatedDate(String createdDate) { this.createdDate = createdDate; }

    public String getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(String updatedDate) { this.updatedDate = updatedDate; }

    public String getSubmissionDate() { return submissionDate; }
    public void setSubmissionDate(String submissionDate) { this.submissionDate = submissionDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getError() { return error; }
    public void setError(String error) { this.error = error; }
}
