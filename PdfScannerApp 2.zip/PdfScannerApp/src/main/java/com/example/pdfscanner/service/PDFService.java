package com.example.pdfscanner.service;

import com.example.pdfscanner.model.PDFRecord;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.*;

@Service
public class PDFService {

            private final Map<String, PDFRecord> store = new ConcurrentHashMap<>();
            private final ExecutorService executor = Executors.newFixedThreadPool(4);

            public String sha256(byte[] data) throws Exception {
                        MessageDigest digest = MessageDigest.getInstance("SHA-256");
                        byte[] hash = digest.digest(data);
                        StringBuilder hex = new StringBuilder();
                        for (byte b : hash) hex.append(String.format("%02x", b));
                        return hex.toString();
            }

            public boolean isPDF(byte[] data) {
                        return data.length >= 4 && data[0] == '%' && data[1] == 'P' && data[2] == 'D' && data[3] == 'F';
            }

            public PDFRecord submitForProcessing(String sha256, byte[] data) {
                        PDFRecord record = new PDFRecord();
                        record.setSha256(sha256);
                        record.setSubmissionDate(Instant.now().toString());
                        record.setStatus("processing");
                        store.put(sha256, record);

                        executor.submit(() -> processPDF(sha256, data));
                        return record;
            }

            private void processPDF(String sha256, byte[] data) {
                        try (PDDocument doc = PDDocument.load(new ByteArrayInputStream(data))) {
                                    PDDocumentInformation info = doc.getDocumentInformation();

                                    PDFRecord rec = store.get(sha256);
                                    rec.setPdfVersion(String.valueOf(doc.getVersion()));
                                    rec.setProducer(info.getProducer());
                                    rec.setAuthor(info.getAuthor());
                                    rec.setCreatedDate(info.getCreationDate() != null ? info.getCreationDate().getTime().toInstant().toString() : null);
                                    rec.setUpdatedDate(info.getModificationDate() != null ? info.getModificationDate().getTime().toInstant().toString() : null);
                                    rec.setStatus("done");
                        } catch (Exception e) {
                                    PDFRecord rec = store.get(sha256);
                                    rec.setStatus("error");
                                    rec.setError(e.getMessage());
                        }
            }

            public PDFRecord lookup(String sha256) {
                        return store.get(sha256);
            }
}
