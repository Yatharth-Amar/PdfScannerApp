package com.example.pdfscanner.controller;

import com.example.pdfscanner.model.PDFRecord;
import com.example.pdfscanner.service.PDFService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class PDFController {

private final PDFService pdfService;

public PDFController(PDFService pdfService) {
        this.pdfService = pdfService;
    }

@PostMapping("/scan")
public ResponseEntity<?> scan(@RequestParam("file") MultipartFile file) {
try {
byte[] bytes = file.getBytes();
if (!pdfService.isPDF(bytes)) {
return ResponseEntity.status(HttpStatus.BAD_REQUEST)
        .body("{\"error\":\"Invalid file type. Only PDF accepted.\"}");
}

String sha = pdfService.sha256(bytes);
pdfService.submitForProcessing(sha, bytes);

return ResponseEntity.ok("{\"sha256\":\"" + sha + "\",\"message\":\"File accepted. Metadata extraction in progress.\"}");
} catch (Exception e) {
return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("{\"error\":\"" + e.getMessage() + "\"}");
}
    }

    @GetMapping("/lookup/{sha256}")
    public ResponseEntity<?> lookup(@PathVariable String sha256) {
        PDFRecord rec = pdfService.lookup(sha256);
        if (rec == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Record not found\"}");
        }

        if ("processing".equals(rec.getStatus())) {
            return ResponseEntity.ok("{\"sha256\":\"" + rec.getSha256() + "\",\"status\":\"processing\",\"submission_date\":\"" + rec.getSubmissionDate() + "\"}");
        }

        return ResponseEntity.ok(rec);
    }
}
